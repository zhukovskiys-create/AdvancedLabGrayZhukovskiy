# Leo Gray portfolio

A plain HTML, CSS and JavaScript site. No build step, no frameworks. Everything you edit is in one file: `data/site.js`.

## Add a project (about five minutes)

1. Copy your best image into `assets/images/` (for example `assets/images/walking-bot.jpg`).
2. Open `data/site.js`, copy the **PROJECT TEMPLATE** at the bottom into the `PROJECTS` list, and fill it in.
3. Save, open `index.html` in your browser to check it, then commit and push.

Each project gets its own link, such as `https://YOUR-SITE/#/p/pulse-oximeter`, which you can paste into applications.

## Add or change a skill

Skills live in `data/site.js` under `SITE.skillsDetail`. Give each skill a one-sentence `note` and the `projects` that prove it, and it appears on the Skills page with links to those projects. Skills with no evidence yet go in the "Also familiar with" group. Add things you are actively learning to `SITE.learning` (it stays hidden while empty).

## See what is still missing

Open the site with `?preview` on the end (for example `index.html?preview`). Every project page then shows a yellow "still to add" box from its `needs` list. Visitors never see it, but delete the notes once a project is finished.

## Before you publish

- In `data/site.js`, confirm `email` and `github`, and add your `linkedin` and `resume` (put the PDF in `assets/`). Empty values hide their buttons.
- Ask your lab partner before naming them or linking a repo they own.
- Do not put your phone number or home address on a public site.

## Publish for free with GitHub Pages

1. Create a new GitHub repository. Naming it `YOUR-USERNAME.github.io` gives you the short address `https://YOUR-USERNAME.github.io`.
2. Add these files to it and push.
3. In the repository go to **Settings > Pages**, choose **Deploy from a branch**, pick `main` and `/ (root)`, and save. The site is live in a minute or two.

## Files

| File | What it is |
| --- | --- |
| `data/site.js` | All your content: about text, experience, skills, projects. |
| `index.html` | The page shell. |
| `css/style.css` | Colors and layout. Change the variables at the top to restyle. |
| `js/app.js` | Builds the pages from your data. |
