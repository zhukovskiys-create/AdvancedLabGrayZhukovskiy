/* ==========================================================================
   YOUR CONTENT LIVES HERE. Edit this file; you should not need to touch
   index.html, css/style.css or js/app.js to add a project.

   TO ADD A PROJECT: copy the template at the bottom of this file into the
   PROJECTS list (newest first is a good habit), fill it in, and save.
   Put images in assets/images/ and refer to them as "assets/images/name.jpg".

   Add ?preview to the site address (for example index.html?preview) to see
   the private "still to add" notes on each project. Visitors never see them.
   ========================================================================== */

window.SITE = {
  name: "Leo Gray",
  tagline: "Physics student building things that sense, move and measure.",
  intro: "I'm a physics major at Brandeis University with a minor in journalism. I like projects where hardware, firmware and data meet: temperature controllers, a pulse oximeter, and a walking combat robot.",
  seeking: "Looking for: technician and entry-level engineering roles in photonics, test and robotics",
  education: {
    school: "Brandeis University",
    degree: "B.S. in Physics, minor in Journalism",
    when: "Expected May 2027",
    coursework: "Intro to Design Methodology, Engineering Instrumentation, Physics Lab I and II, Electromagnetism, Linear Algebra, Problem Solving in Python"
  },
  experience: [
    {
      role: "Lab Assistant, Physics Department",
      org: "Brandeis University",
      when: "Present",
      text: "Support a faculty research group working on the CERN particle collider upgrade, applying machine learning with PyTorch and TensorFlow."
    },
    {
      role: "Vice President, Brandeis Robotics Team (Deisy Robotics)",
      org: "Brandeis University",
      when: "Sep 2023 - Present",
      text: "Manage team operations, organize events and oversee construction of team projects using CAD and 3D printing resources."
    }
  ],
  skills: [
    { group: "CAD and fabrication", items: ["Fusion 360", "AutoCAD", "FDM 3D printing", "Rapid prototyping"] },
    { group: "Electronics", items: ["KiCad", "Soldering", "WaveForms", "Sensor integration", "Arduino firmware"] },
    { group: "Programming", items: ["Python", "C++", "Java", "R Studio"] },
    { group: "Controls and modeling", items: ["P, PI and feedforward control", "Thermal modeling", "Data logging and analysis"] },
    { group: "Machine learning", items: ["PyTorch", "TensorFlow", "Neural networks"] }
  ],
  /* Leave a link empty ("") to hide its button. Confirm these before you publish. */
  email: "leogray@brandeis.edu",
  github: "https://github.com/LeoGray536",
  linkedin: "",
  resume: "",            /* for example "assets/Leo_Gray_Resume.pdf" */
  footerNote: "Built by hand with plain HTML, CSS and JavaScript."
};

window.PROJECTS = [
  {
    id: "walking-combat-bot",
    title: "Combat Robotics Walking Bot",
    kind: "Robotics",
    status: "Ongoing",
    dates: "Feb 2024 - Present",
    featured: true,
    summary: "A 3-lb combat robot that walks using the torque from its angular-mounted weapons for locomotion.",
    tags: ["Rapid prototyping", "Mechanical design", "Robotics"],
    image: "",
    imageAlt: "",
    role: "Independent project",
    tools: [],
    sections: [
      { heading: "The idea",
        body: ["A novel 3-lb walking bot that uses the torque from its angular-mounted weapons for locomotion."] },
      { heading: "Prototyping",
        body: ["I am fabricating a 1-lb plastic prototype to test how effective torque-driven motion is, and using it to iterate on the design constraints."] }
    ],
    results: [],
    links: [],
    needs: [
      "Add photos or a short video of the prototype walking.",
      "Motors and drive electronics: which parts, and why.",
      "Test results: step length, speed, battery life, what failed and what you changed.",
      "A CAD render or exploded view of the 3-lb design.",
      "Add the CAD and fabrication tools you used (your resume lists Fusion 360 and FDM 3D printing, but does not tie them to this project)."
    ]
  },
  {
    id: "pulse-oximeter",
    title: "Pulse Oximeter",
    kind: "Electronics",
    status: "Complete",
    dates: "Spring 2025",
    featured: true,
    summary: "A functional pulse oximeter that integrates sensor hardware to monitor blood oxygen levels.",
    tags: ["Sensors", "Electronics"],
    image: "",
    imageAlt: "",
    role: "Brandeis University project",
    tools: ["Sensor hardware"],
    sections: [
      { heading: "Overview",
        body: ["I designed and built a working pulse oximeter at Brandeis, integrating sensor hardware to monitor blood oxygen levels."] }
    ],
    results: [],
    links: [],
    needs: [
      "Which sensor and microcontroller you used, and how the light is measured.",
      "How you checked it: accuracy against a commercial oximeter, with a plot or table.",
      "A photo of the build and the schematic or board layout.",
      "Add the tools you used (for example KiCad, soldering, WaveForms) once you confirm they were part of this build."
    ]
  },
  {
    id: "tec-temperature-controller",
    title: "Thermoelectric Temperature Controller",
    kind: "Controls",
    status: "Complete",
    dates: "Fall 2026",
    featured: false,
    summary: "A temperature controller built from the sensor up: thermistors, an H-bridge, Arduino firmware and a Python interface, with P, PI and feedforward control tested on real hardware.",
    tags: ["Arduino", "Python", "Control systems", "Data acquisition", "Thermal modeling"],
    image: "",
    imageAlt: "",
    role: "Brandeis Advanced Lab, with a lab partner",
    tools: ["Arduino (C++)", "Python", "PySide6", "pyqtgraph", "pySerial", "Thermistors", "H-bridge", "Thermoelectric cooler"],
    sections: [
      { heading: "What it does",
        body: ["A thermoelectric cooler (TEC) heats or cools depending on the direction of current, which makes it a good platform for learning feedback control. Over several lab modules my partner and I built the whole system: sensing, power electronics, firmware, a PC interface, and the control and modeling on top."] },
      { heading: "Firmware and safety",
        body: ["The Arduino converts thermistor readings to temperature with the Beta equation, averaging 500 samples per reading, and drives the TEC through an H-bridge using a signed PWM value (positive heats, negative cools). A custom serial protocol carries commands and telemetry. A 60 C software cutoff shuts the output off, backed by an independent hardware thermal switch at about 70 C.",
               "A later version reads six thermistor channels every 5 seconds and accepts uploaded setpoint schedules, including sinusoidal setpoints."] },
      { heading: "PC interface and automation",
        body: ["A PySide6 and pyqtgraph application plots live temperature, logs everything to CSV, and runs automated steady-state sweeps: heating and cooling at 0, 25, 50, 75 and 100 percent power, waiting for each temperature to settle before moving on."] },
      { heading: "Control and modeling",
        body: ["We implemented proportional (P) control, then PI control with anti-windup and feedforward built from the measured steady-state heating and cooling curves. A one- and two-lump thermal model simulates the system, and the same interface can drive either the model or the real hardware."] }
    ],
    results: [
      "With a 15 C setpoint, low proportional gains (2 or less) left the temperature about 6 C above the setpoint, while a gain of 12 held it at 15.5 C with almost no scatter.",
      "The software cutoff and hardware switch give two independent layers of over-temperature protection.",
      "Steady-state sweeps cover five power levels in both heating and cooling."
    ],
    links: [],
    needs: [
      "Add plots: the repo has ten_step_graphs, trace_plots and steady_state_temperature_vs_signed_pwm.png. Copy the best into assets/images and add them as images.",
      "Add the GitHub repo link once your lab partner confirms it is public, and ask their permission before naming them.",
      "Say which parts you wrote versus your partner.",
      "Add one more number if you have it: temperature accuracy, or the time constant you measured."
    ]
  },
  {
    id: "prosthetic-hand",
    title: "Prosthetic Hand",
    kind: "Mechanical design",
    status: "Complete",
    dates: "Spring 2023",
    featured: false,
    summary: "A remodeled, FDM-manufacturable prosthetic hand, redesigned with design methodology to improve functionality and manufacturability.",
    tags: ["CAD", "3D printing", "Design for manufacturing"],
    image: "",
    imageAlt: "",
    role: "Brandeis University project",
    tools: ["CAD", "FDM 3D printing"],
    sections: [
      { heading: "Overview",
        body: ["I remodeled and built a prosthetic hand that can be produced on an FDM 3D printer, applying design methodology to improve both how it works and how easily it can be made."] }
    ],
    results: [],
    links: [],
    needs: [
      "What you changed from the original design, and why it prints better.",
      "Photos of the finished hand and a CAD render.",
      "Any measurement: print time, part count, grip test."
    ]
  }
];


/* ------------------------------ SKILLS PAGE ------------------------------
   Each skill can have:
     note:     one sentence on what you actually did with it
     projects: ids of projects (from the list above) that prove it
     link:     { label, href } for evidence that is not a project page
   A skill with no note and no projects is shown in the "Also familiar with"
   list at the bottom. Only list what you can talk about in an interview.
   Add skills you are learning to SITE.learning below; it stays hidden while empty.
--------------------------------------------------------------------------- */
window.SITE.skillsIntro = "Each skill links to the projects where I used it. Skills I have not yet used in a project are listed separately at the bottom.";
window.SITE.skillsDetail = [
  { group: "Controls and modeling", skills: [
    { name: "P, PI and feedforward control",
      note: "Implemented P control, PI control with anti-windup, and feedforward built from measured steady-state curves, then compared gains on real hardware.",
      projects: ["tec-temperature-controller"] },
    { name: "Thermal modeling and simulation",
      note: "Built one- and two-lump thermal models to simulate the controller; the same interface can drive the model or the real hardware.",
      projects: ["tec-temperature-controller"] },
    { name: "Data logging and analysis",
      note: "CSV logging, automated steady-state sweeps and plots of every run.",
      projects: ["tec-temperature-controller"] }
  ]},
  { group: "Embedded systems and electronics", skills: [
    { name: "Arduino firmware (C++)",
      note: "Thermistor reading with 500-sample averaging, signed PWM to an H-bridge, a serial command protocol and a software over-temperature cutoff.",
      projects: ["tec-temperature-controller"] },
    { name: "Sensor integration",
      note: "Integrated sensor hardware in a pulse oximeter, and read six thermistor channels in the temperature controller.",
      projects: ["pulse-oximeter", "tec-temperature-controller"] },
    { name: "Safety and fault handling",
      note: "Two independent over-temperature protections: a 60 C software cutoff and a hardware thermal switch at about 70 C.",
      projects: ["tec-temperature-controller"] }
  ]},
  { group: "Programming", skills: [
    { name: "Python",
      note: "Control and data-acquisition applications (PySide6, tkinter), serial communication, simulation and plotting.",
      projects: ["tec-temperature-controller"] },
    { name: "C++",
      note: "Firmware for the thermoelectric temperature controller.",
      projects: ["tec-temperature-controller"] },
    { name: "Git and GitHub",
      note: "Shared repository with a lab partner, including merges and a pull request.",
      projects: ["tec-temperature-controller"] }
  ]},
  { group: "Machine learning", skills: [
    { name: "PyTorch, TensorFlow and neural networks",
      note: "Applied in my lab assistant role supporting the CERN collider upgrade.",
      link: { label: "See experience", href: "#/experience" } }
  ]},
  { group: "CAD and fabrication", skills: [
    { name: "CAD (Fusion 360, AutoCAD)",
      note: "Remodeled a prosthetic hand in CAD so it can be manufactured on an FDM printer.",
      projects: ["prosthetic-hand"] },
    { name: "FDM 3D printing",
      note: "Designed the prosthetic hand to be FDM-manufacturable.",
      projects: ["prosthetic-hand"] },
    { name: "Rapid prototyping and design iteration",
      note: "Fabricating a 1-lb plastic prototype to test torque-driven motion and iterate on design constraints.",
      projects: ["walking-combat-bot"] },
    { name: "Design for manufacturing",
      note: "Remodeled the prosthetic hand so it can be produced on an FDM printer.",
      projects: ["prosthetic-hand"] }
  ]},
  { group: "Teamwork and leadership", skills: [
    { name: "Team leadership",
      note: "Vice President of Brandeis Robotics (Deisy Robotics): team operations, events and project construction.",
      link: { label: "See experience", href: "#/experience" } }
  ]},
  { group: "Also familiar with", skills: [
    { name: "KiCad" }, { name: "Soldering" }, { name: "WaveForms" },
    { name: "Java" }, { name: "R Studio" }, { name: "Electromagnetism and waves (coursework)" },
    { name: "Engineering instrumentation (coursework)" }
  ]}
];
/* Skills you are actively learning, shown as a short list on the Skills page.
   Example: ["ROS 2", "MATLAB"]. Leave empty to hide the section. */
window.SITE.learning = [];

/* ---------------------------- PROJECT TEMPLATE ----------------------------
  Copy everything between the braces into the PROJECTS list above. Delete any
  field you do not need; empty ones are simply skipped on the page.

  {
    id: "short-url-name",              // letters, numbers and dashes only
    title: "Project Title",
    kind: "Robotics",                  // one word or short phrase
    status: "Complete",                // Ongoing, Complete, Paused...
    dates: "Mon YYYY - Mon YYYY",
    featured: false,                   // true puts it at the top of the home page
    summary: "One or two sentences that make someone want to read more.",
    tags: ["Python", "OpenCV"],        // used for the filter buttons
    image: "assets/images/cover.jpg",
    imageAlt: "What the picture shows",
    role: "What you did",
    team: "Team of 2",
    tools: ["Fusion 360", "Arduino"],
    sections: [
      { heading: "The problem", body: ["Paragraph one.", "Paragraph two."] },
      { heading: "How it works", body: ["..."] }
    ],
    gallery: [
      { src: "assets/images/plot1.png", alt: "Describe the plot", caption: "Figure 1: ..." }
    ],
    results: ["A measured result with a number."],
    links: [ { label: "Source code", url: "https://github.com/..." } ],
    needs: ["Private reminder to yourself; only shown with ?preview."]
  }
------------------------------------------------------------------------- */
