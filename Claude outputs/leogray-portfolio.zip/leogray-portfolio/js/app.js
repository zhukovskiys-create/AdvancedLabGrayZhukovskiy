/* Renders the portfolio from data/site.js. You normally never edit this file. */
(function () {
  "use strict";

  var S = window.SITE || {};
  var P = window.PROJECTS || [];
  var PREVIEW = /[?&]preview(=|&|$)/.test(window.location.search);
  var main = document.getElementById("main");
  var activeTag = "All";

  function el(tag, attrs, kids) {
    var e = document.createElement(tag);
    var k;
    attrs = attrs || {};
    for (k in attrs) {
      if (!Object.prototype.hasOwnProperty.call(attrs, k)) continue;
      var v = attrs[k];
      if (v === null || v === undefined || v === false) continue;
      if (k === "class") e.className = v;
      else if (k === "text") e.textContent = v;
      else e.setAttribute(k, v);
    }
    (kids || []).forEach(function (c) {
      if (c === null || c === undefined || c === false) return;
      e.appendChild(typeof c === "string" ? document.createTextNode(c) : c);
    });
    return e;
  }

  function clear(node) { while (node.firstChild) node.removeChild(node.firstChild); }

  function safeUrl(u) {
    return /^(https?:|mailto:|assets\/|\.\/|#)/.test(u || "") ? u : "";
  }

  /* ------------------------------ shared pieces ------------------------------ */
  function renderChrome() {
    var brand = document.getElementById("brand");
    clear(brand);
    var parts = (S.name || "Portfolio").split(" ");
    brand.appendChild(document.createTextNode(parts[0] + " "));
    brand.appendChild(el("span", { text: parts.slice(1).join(" ") }));

    var nav = document.getElementById("nav");
    clear(nav);
    [["Projects", "#/projects"], ["Experience", "#/experience"], ["Skills", "#/skills"], ["Contact", "#/contact"]]
      .forEach(function (l) { nav.appendChild(el("a", { href: l[1], text: l[0] })); });

    var foot = document.getElementById("footer");
    clear(foot);
    foot.appendChild(el("span", { text: "© " + new Date().getFullYear() + " " + (S.name || "") }));
    if (S.footerNote) foot.appendChild(el("span", { text: S.footerNote }));
  }

  function mediaFor(p) {
    if (p.image) {
      return el("img", { class: "media", src: safeUrl(p.image), alt: p.imageAlt || p.title, loading: "lazy" });
    }
    return el("div", { class: "ph", "aria-hidden": "true", text: p.kind || "" });
  }

  function tagRow(tags) {
    return el("div", { class: "tags" }, (tags || []).map(function (t) { return el("span", { class: "tag", text: t }); }));
  }

  function card(p) {
    var meta = el("div", { class: "meta" }, [
      p.kind && el("span", { text: p.kind }),
      p.status && el("span", { text: p.status }),
      p.dates && el("span", { text: p.dates })
    ]);
    return el("a", { class: "card", href: "#/p/" + encodeURIComponent(p.id) }, [
      mediaFor(p),
      el("div", { class: "body" }, [
        meta,
        el("h3", { text: p.title }),
        el("p", { text: p.summary || "" }),
        tagRow(p.tags)
      ])
    ]);
  }

  /* ---------------------------------- home ---------------------------------- */
  function heroSection() {
    var links = [];
    if (S.github) links.push(el("a", { class: "btn", href: safeUrl(S.github), text: "GitHub" }));
    if (S.linkedin) links.push(el("a", { class: "btn", href: safeUrl(S.linkedin), text: "LinkedIn" }));
    if (S.resume) links.push(el("a", { class: "btn", href: safeUrl(S.resume), text: "Resume (PDF)" }));
    if (S.email) links.unshift(el("a", { class: "btn primary", href: "mailto:" + S.email, text: "Email me" }));
    return el("section", { class: "hero", id: "top", style: "border-top:0" }, [
      el("p", { class: "eyebrow", text: "Portfolio" }),
      el("h1", { text: S.name || "" }),
      el("p", { class: "lede", text: S.tagline || "" }),
      S.intro && el("p", { class: "lede", text: S.intro }),
      S.seeking && el("p", { class: "seeking", text: S.seeking }),
      el("div", { class: "actions" }, links)
    ]);
  }

  function projectsSection() {
    var tags = ["All"];
    P.forEach(function (p) { (p.tags || []).forEach(function (t) { if (tags.indexOf(t) < 0) tags.push(t); }); });

    var featured = P.filter(function (p) { return p.featured; });
    var kids = [];

    if (featured.length) {
      kids.push(el("section", { id: "featured" }, [
        el("h2", { text: "Featured projects" }),
        el("div", { class: "grid featured" }, featured.map(card))
      ]));
    }

    var grid = el("div", { class: "grid", id: "grid" });
    var chips = el("div", { class: "chips", role: "group", "aria-label": "Filter projects by skill" });

    function fill() {
      clear(grid);
      P.filter(function (p) { return activeTag === "All" || (p.tags || []).indexOf(activeTag) >= 0; })
        .forEach(function (p) { grid.appendChild(card(p)); });
      Array.prototype.forEach.call(chips.children, function (c) {
        c.setAttribute("aria-pressed", c.textContent === activeTag ? "true" : "false");
      });
    }
    tags.forEach(function (t) {
      var b = el("button", { class: "chip", type: "button", text: t, "aria-pressed": "false" });
      b.addEventListener("click", function () { activeTag = t; fill(); });
      chips.appendChild(b);
    });
    fill();

    kids.push(el("section", { id: "projects" }, [el("h2", { text: "All projects" }), chips, grid]));
    return kids;
  }

  function experienceSection() {
    var items = (S.experience || []).map(function (j) {
      return el("div", { class: "job" }, [
        el("h3", { text: j.role }),
        el("div", { class: "when", text: [j.org, j.when].filter(Boolean).join("  |  ") }),
        el("p", { text: j.text || "" })
      ]);
    });
    var edu = S.education;
    if (edu) {
      items.push(el("div", { class: "job" }, [
        el("h3", { text: edu.school + ": " + edu.degree }),
        el("div", { class: "when", text: edu.when || "" }),
        edu.coursework && el("p", { text: "Relevant coursework: " + edu.coursework })
      ]));
    }
    return el("section", { id: "experience" }, [el("h2", { text: "Experience and education" }), el("div", { class: "timeline" }, items)]);
  }

  function skillsSection() {
    var groups = (S.skills || []).map(function (g) {
      return el("div", {}, [
        el("h3", { text: g.group }),
        el("ul", {}, g.items.map(function (i) { return el("li", { text: i }); }))
      ]);
    });
    return el("section", { id: "skills" }, [
      el("h2", { text: "Skills" }),
      el("div", { class: "skillgroups" }, groups),
      S.skillsDetail ? el("p", { class: "more" }, [el("a", { class: "btn", href: "#/skills", text: "See the projects behind each skill" })]) : null
    ]);
  }

  function contactSection() {
    var links = [];
    if (S.email) links.push(el("a", { class: "btn primary", href: "mailto:" + S.email, text: S.email }));
    if (S.github) links.push(el("a", { class: "btn", href: safeUrl(S.github), text: "GitHub" }));
    if (S.linkedin) links.push(el("a", { class: "btn", href: safeUrl(S.linkedin), text: "LinkedIn" }));
    return el("section", { id: "contact" }, [
      el("h2", { text: "Contact" }),
      el("p", { text: "The best way to reach me is by email." }),
      el("div", { class: "actions" }, links)
    ]);
  }

  function renderHome(anchor) {
    clear(main);
    document.title = (S.name || "Portfolio") + " | Portfolio";
    main.appendChild(heroSection());
    projectsSection().forEach(function (s) { main.appendChild(s); });
    main.appendChild(experienceSection());
    main.appendChild(skillsSection());
    main.appendChild(contactSection());
    if (anchor) {
      var t = document.getElementById(anchor);
      if (t && t.scrollIntoView) t.scrollIntoView();
      else window.scrollTo(0, 0);
    } else {
      window.scrollTo(0, 0);
    }
  }

  /* -------------------------------- skills page ------------------------------- */
  function projectTitle(id) {
    var t = null;
    P.forEach(function (x) { if (x.id === id) t = x.title; });
    return t;
  }

  function skillCard(sk) {
    var proof = [];
    (sk.projects || []).forEach(function (id) {
      var t = projectTitle(id);
      if (t) proof.push(el("a", { href: "#/p/" + encodeURIComponent(id), text: t }));
    });
    if (sk.link) proof.push(el("a", { href: safeUrl(sk.link.href), text: sk.link.label }));
    return el("div", { class: "skillcard" }, [
      el("h3", { text: sk.name }),
      sk.note && el("p", { text: sk.note }),
      proof.length ? el("div", { class: "proof" }, proof) : null
    ]);
  }

  function renderSkills() {
    clear(main);
    window.scrollTo(0, 0);
    document.title = "Skills | " + (S.name || "");
    var page = el("div", { class: "skillspage" }, [
      el("a", { class: "back", href: "#/", text: "< Home" }),
      el("h1", { text: "Skills", style: "margin:8px 0 12px;font-size:clamp(1.8rem,4.5vw,2.6rem);letter-spacing:-0.02em" }),
      el("p", { class: "lede", text: S.skillsIntro || "" })
    ]);
    (S.skillsDetail || []).forEach(function (g) {
      var proven = g.skills.filter(function (k) { return k.note || (k.projects && k.projects.length) || k.link; });
      var plain = g.skills.filter(function (k) { return !(k.note || (k.projects && k.projects.length) || k.link); });
      var sec = el("section", { class: "skillgroup" }, [el("h2", { text: g.group })]);
      if (proven.length) sec.appendChild(el("div", { class: "skilllist" }, proven.map(skillCard)));
      if (plain.length) {
        sec.appendChild(el("ul", { class: "tags", style: "list-style:none;padding:0;margin:0" },
          plain.map(function (k) { return el("li", { class: "tag", text: k.name }); })));
      }
      page.appendChild(sec);
    });
    if (S.learning && S.learning.length) {
      page.appendChild(el("section", { class: "skillgroup" }, [
        el("h2", { text: "Currently learning" }),
        el("ul", { class: "tags", style: "list-style:none;padding:0;margin:0" },
          S.learning.map(function (k) { return el("li", { class: "tag", text: k }); }))
      ]));
    }
    main.appendChild(page);
  }

  /* ------------------------------- project page ------------------------------ */
  function renderProject(id) {
    var p = null;
    P.forEach(function (x) { if (x.id === id) p = x; });
    clear(main);
    window.scrollTo(0, 0);
    if (!p) {
      document.title = "Not found | " + (S.name || "");
      main.appendChild(el("a", { class: "back", href: "#/projects", text: "< All projects" }));
      main.appendChild(el("h1", { text: "Project not found" }));
      return;
    }
    document.title = p.title + " | " + (S.name || "");

    var facts = [];
    function fact(label, value) { if (value) facts.push(el("div", { class: "fact" }, [el("b", { text: label }), el("span", { text: value })])); }
    fact("Status", p.status);
    fact("When", p.dates);
    fact("Role", p.role);
    fact("Team", p.team);
    if (p.tools && p.tools.length) fact("Tools", p.tools.join(", "));

    var prose = el("div", { class: "prose" });
    (p.sections || []).forEach(function (s) {
      prose.appendChild(el("h2", { text: s.heading }));
      (s.body || []).forEach(function (para) { prose.appendChild(el("p", { text: para })); });
    });
    if (p.gallery && p.gallery.length) {
      prose.appendChild(el("div", { class: "gallery" }, p.gallery.map(function (g) {
        return el("figure", {}, [
          el("img", { src: safeUrl(g.src), alt: g.alt || "", loading: "lazy" }),
          g.caption && el("figcaption", { text: g.caption })
        ]);
      })));
    }
    if (p.results && p.results.length) {
      prose.appendChild(el("h2", { text: "Results" }));
      prose.appendChild(el("ul", {}, p.results.map(function (r) { return el("li", { text: r }); })));
    }
    if (p.links && p.links.length) {
      prose.appendChild(el("h2", { text: "Links" }));
      prose.appendChild(el("div", { class: "actions" }, p.links.map(function (l) {
        return el("a", { class: "btn", href: safeUrl(l.url), text: l.label });
      })));
    }

    var todo = null;
    if (PREVIEW && p.needs && p.needs.length) {
      todo = el("div", { class: "todo" }, [
        el("b", { text: "STILL TO ADD (only visible with ?preview)" }),
        el("ul", {}, p.needs.map(function (n) { return el("li", { text: n }); }))
      ]);
    }

    main.appendChild(el("article", { class: "proj" }, [
      el("a", { class: "back", href: "#/projects", text: "< All projects" }),
      el("div", { class: "meta" }, [p.kind && el("span", { text: p.kind })]),
      el("h1", { text: p.title }),
      el("p", { class: "lede", text: p.summary || "" }),
      p.image ? mediaFor(p) : null,
      el("div", { class: "facts" }, facts),
      tagRow(p.tags),
      todo,
      prose
    ]));
  }

  /* --------------------------------- routing --------------------------------- */
  function route() {
    var h = window.location.hash || "#/";
    var m = h.match(/^#\/p\/(.+)$/);
    if (m) return renderProject(decodeURIComponent(m[1]));
    if (h === "#/skills") return renderSkills();
    var anchors = { "#/projects": "projects", "#/experience": "experience", "#/contact": "contact" };
    renderHome(anchors[h] || null);
    main.focus({ preventScroll: true });
  }

  renderChrome();
  window.addEventListener("hashchange", route);
  route();
})();
